import nibabel as nib
import matplotlib.pyplot as plt
import numpy as np
import time

# Lade die NIfTI-Datei
nifti_file = './sub-10005_ses-s4_T1w.nii.gz'
img = nib.load(nifti_file)

# Extrahiere die Daten als NumPy-Array
data = img.get_fdata()
print(data.shape)

# Initialisiere die Figur
plt.ion()  # Interaktive Anzeige aktivieren
fig, ax = plt.subplots()

# Durch alle Schichten iterieren
for slice_index in range(30,data.shape[0]-30):
    ax.clear()  # Aktuelle Achse löschen
    slice_data = data[slice_index, :, :]  # Wähle die Schicht
    ax.imshow(slice_data.T, cmap="gray", origin="lower")  # Bild anzeigen
    ax.set_title(f'Slice {slice_index}')
    ax.axis('off')
    plt.draw()  # Zeichnung aktualisieren
    plt.pause(0.1)  # Pause für 0,1 Sekunden

plt.ioff()  # Interaktive Anzeige deaktivieren
plt.show()  # Finale Anzeige


